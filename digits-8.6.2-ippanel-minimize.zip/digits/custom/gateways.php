<?php
add_filter('digits_sms_gateways', 'digits_custom_ippanel_gateway_list'); function digits_custom_ippanel_gateway_list($gateways) { return array( 'ippanel' => array( 'value' => 1000, 'label' => 'ippanel.com - آی پی پنل', 'inputs' => array( __('Api key') => array( 'text' => true, 'name' => 'apikey', 'desc' => ' جهت دریافت کلید API،  درسامانه پیامک به صفحه برنامه نویسان> کلیدهای دسترسی مراجعه کنید و کلید دسترسی ایجاد کنید و سپس آن را به این کادر کپی نمایید.
' ), __('Sender') => array( 'text' => true, 'name' => 'sender', 'desc' => 'شماره خط ارسال کننده خدماتی خود را وارد نمایید. در صورتی که خط خدماتی اختصاصی ندارید از شماره اشتراکی 3000505 استفاده نمایی. این شماره قبلا بایستی به پنل شما متصل شده باشد.' ), __('Send by pattern') => array( 'options' => array( __('No') => 0, __('Yes') => 1 ), 'name' => 'pattern', 'optional' => 1, 'desc' => 'جهت ارسال پیامک سریع با پترن این گزینه را فعال نمایید.<script>
jQuery(document).ready(function($) {
    function togglePatternFields(animate) {
        var patternSelect = $("#ippanel_pattern");
        var patterncodeRow = $("#ippanel_patterncode").closest("tr");
        var patternvarsRow = $("#ippanel_patternvars").closest("tr");
        
        if (patternSelect.length && patterncodeRow.length && patternvarsRow.length) {
            var patternValue = patternSelect.val();
            if (patternValue == "1") {
                if (animate) {
                    patterncodeRow.slideDown(500);
                    patternvarsRow.slideDown(500);
                } else {
                    patterncodeRow.show();
                    patternvarsRow.show();
                }
            } else {
                if (animate) {
                    patterncodeRow.slideUp(500);
                    patternvarsRow.slideUp(500);
                } else {
                    patterncodeRow.hide();
                    patternvarsRow.hide();
                }
            }
        }
    }
    
    // اجرا در لود صفحه (بدون انیمیشن)
    setTimeout(function() {
        togglePatternFields(false);
    }, 100);
    
    // اجرا در تغییر مقدار (با انیمیشن)
    $(document).on("change", "#ippanel_pattern", function() {
        togglePatternFields(true);
    });
});
</script>' ), __('Pattern Code') => array( 'text' => true, 'name' => 'patterncode', 'optional' => 1, 'desc' => 'جهت ارسال پیامک های پترنی، کد پترن را وارد کنید. در صورتی که قبلا در سامانه پیامک پترن ایجاد نکردید، به سامانه پیامک بخش پیامک های متغیر دار وارد شوید و پترن با متنی مشابه زیر بسازید:<br> کد تأیید شما: %code%<br>فروشگاه من' ), __('Pattern Variable') => array( 'text' => true, 'name' => 'patternvars', 'optional' => 1, 'desc' => 'فقط کلمه متغیری که در متن پترن ثبت کرده اید وارد نمایید. مثلا code' ), ) ) ); } add_filter( 'unitedover_send_sms', 'digits_ippanel_send', 10, 8); function digits_ippanel_send($value, $option_slug, $gateway_id, $countrycode, $mobile, $messagetemplate, $testCall, $otp){ if(!class_exists('digits_ippanel_Sms_gateway')){ require_once __DIR__ .'/ippanel/class-ippanel.php'; } try { $ippanelSettings = get_option('digit_ippanel'); $ippanel = new digits_Ippanel($ippanelSettings); $pattern = $ippanelSettings['pattern']; $param = array ( 'otp' => $otp, 'to' => $mobile, 'message' => $messagetemplate, ); if ($pattern == 1) { $result = $ippanel->sendPattern( $param ); } else { $result = $ippanel->send( $param ); } $response = json_decode($result, true); $success_message = 'ارسال موفقیت آمیز : '; $fault_message = 'خطا در ارسال. پاسخ پنل پیامک: '; if (isset($response['meta']['status']) && $response['meta']['status'] === true && isset($response['data']['message_outbox_ids'])) { if ($testCall) return $success_message.$response['meta']['message'] . " - شناسه ارسال: " . $response['data']['message_outbox_ids'][0]; return true; }else{ $error_message = isset($response['meta']['message']) ? $response['meta']['message'] : 'خطای نامشخص'; $error_code = isset($response['meta']['message_code']) ? $response['meta']['message_code'] : 'نامشخص'; if ($testCall) return $fault_message.$error_code . " - " . $error_message; error_log("ippanel SMS failed :".json_encode(array('message'=>$messagetemplate,'to'=>$mobile,'error'=>$error_message,'error_code'=>$error_code))); return false; } } catch (Exception $e) { return false; } }